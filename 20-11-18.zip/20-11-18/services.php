<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Services | DailHari</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content=""
	/>
	<link rel="shortcut icon" type="image/png" href="images/favicon.png">
	<link rel="stylesheet" type="text/css" href="css/services.css">
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->

	<!-- Custom-Files -->
	<!-- Bootstrap-Core-Css -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Testimonials-Css -->
	<link href="css/mislider.css" rel="stylesheet" type="text/css" />
	<link href="css/mislider-custom.css" rel="stylesheet" type="text/css" />
    <link href="css/tvrepair.css" rel="stylesheet" type="text/css" />
	<!-- Style-Css -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Font-Awesome-Icons-Css -->
	<link rel="stylesheet" href="css/fontawesome-all.css">
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
	 rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
	<!-- //Web-Fonts -->
    <script src="form2.js"></script>
<style>
    .banner-text-whtree {

    max-width: 600px;
    padding-top: 13em;
   margin-left: 1020px;
}
    </style>
    <style>
        .counter_form
{
	position: absolute;
	top: 0;
	right: 30px;
	width: 380px;
	/*! height: 100%; */
	background: #FFFFFF;
	padding-left: 40px;
	padding-right: 40px;
	margin-top: 150px;
	box-shadow: 0px 5px 40px rgba(29,34,47,0.15);
}
.counter_form_content
{
	display: block;
	position: relative;
	width: 100%;
	height: 100%;
}
.counter_form_title
{
	font-family: 'Roboto Slab', serif;
	font-size: 24px;
	font-weight: 700;
	color: #384158;
	text-transform: uppercase;
	line-height: 0.75;
	margin-bottom: 40px;
	padding-top: 22px;
}
.counter_input
{
	width: 100%;
	height: 46px;
	border: solid 1px #e5e5e5;
	border-radius: 3px;
	padding-left: 20px;
	outline: none;
	color: #384158;
	font-size: 14px;
}
.counter_input:not(:last-child)
{
	margin-bottom: 10px;
}
.counter_text_input
{
	height: 90px;
	padding-top: 10px;
}
.counter_options
{
	position: relative;
	-webkit-appearance: none;
    -moz-appearance: none;
    -ms-appearance: none;
    -o-appearance: none;
    appearance: none;
    -webkit-box-shadow: 0px 0px 0px rgba(0, 0, 0, 0);
	-webkit-user-select: none;
	background-image: url(../images/down.png);
	background-position: center right;
	background-repeat: no-repeat;
}
.counter_input::-webkit-input-placeholder,
.counter_text_input::-webkit-input-placeholder
{
	font-size: 14px !important;
	font-weight: 400 !important;
	color: #b5b8be !important;
}
.counter_input:-moz-placeholder,
.counter_text_input:-moz-placeholder
{
	font-size: 14px !important;
	font-weight: 400 !important;
	color: #b5b8be !important;
}
.counter_input::-moz-placeholder,
.counter_text_input::-moz-placeholder
{
	font-size: 14px !important;
	font-weight: 400 !important;
	color: #b5b8be !important;
} 
.counter_input:-ms-input-placeholder,
.counter_text_input:-ms-input-placeholder
{ 
	font-size: 14px !important;
	font-weight: 400 !important;
	color: #b5b8be !important;
}
.counter_input::input-placeholder,
.counter_text_input::input-placeholder
{
	font-size: 14px !important;
	font-weight: 400 !important;
	color: #b5b8be !important;
}
.counter_form_button
{
	width: 100%;
	height: 46px;
	color: #000;
	font-size: 14px;
	font-weight: 500;
	text-transform: uppercase;
	border: none;
	outline: none;
	background: #FFD700;
	cursor: pointer;
	margin-top: 30px;
	box-shadow: 0px 5px 40px rgba(29,34,47,0.15);
	-webkit-transition: all 200ms ease;
	-moz-transition: all 200ms ease;
	-ms-transition: all 200ms ease;
	-o-transition: all 200ms ease;
	transition: all 200ms ease;
	margin-bottom: 20px;
}
.counter_form_button:hover
{
	box-shadow: 0px 5px 40px rgba(29,34,47,0.45);
}

    </style>
</head>

<body>
	<!-- header -->
	<header>
		
		<!-- middle header -->
		<div class="middle-w3ls-nav py-2">
			<div class="container">
				<div class="row">
					<a class="logo font-italic font-weight-bold col-lg-4 text-lg-left text-center" href="index.html"><img src="images/logo.png" style="width: 50%;"></a>
					<div class="col-lg-8 right-info-agiles mt-lg-0 mt-sm-3 mt-1">
						<div class="row">
							<div class="col-sm-4 nav-middle">
								<i class="far fa-envelope-open text-center mr-md-4 mr-sm-2 mr-4"></i>
								<div class="agile-addresmk">
									<p>
										<span class="font-weight-bold text-dark">Mail Us</span>
										<a href="mailto:mail@example.com">info@dailhari.com</a>
									</p>
								</div>
							</div>
							<div class="col-sm-4 col-6 nav-middle mt-sm-0 mt-2">
								<i class="fas fa-phone-volume text-center mr-md-4 mr-sm-2 mr-4"></i>
								<div class="agile-addresmk">
									<p>
										<span class="font-weight-bold text-dark">Call Us</span>
										+91 99999 99999
									</p>
								</div>
							</div>
							<!-- <div class="col-sm-4 col-6 top-login-butt text-right mt-sm-2">
								<a href="login.html" class="button-head-mow3 text-white">Login</a>
							</div> -->
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- //middle header -->
	</header>
	<!-- //header -->

	<!-- banner -->
	<div class="banner-agile-2">
		<!-- navigation -->
		<div class="navigation-w3ls">
			<nav class="navbar navbar-expand-lg navbar-light bg-light sticky-nav">
				<button class="navbar-toggler mx-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				 aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse text-center" id="navbarSupportedContent">
					<ul class="navbar-nav justify-content-center">
						<li class="nav-item">
							<a class="nav-link text-white" href="index.html">Home</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="about.html">About Us</a>
						</li>
						<li class="nav-item dropdown active">
							<a class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							Services
							</a>
							<div class="dropdown-menu" style="width: 1000px; columns: 3; -webkit-columns: 3;-moz-columns: 3;">
									<a class="dropdown-item" href="services.html">TV Repairs</a>
									<a class="dropdown-item" href="services.html">Refrigerator Repair</a>
									<a class="dropdown-item" href="services.html">Washing Machine Repair</a>
									<a class="dropdown-item" href="services.html">Micro Owen Repair</a>
									<a class="dropdown-item" href="services.html">AC Repair</a>
									<a class="dropdown-item" href="services.html">Geyser Repair</a>
									<a class="dropdown-item" href="services.html">Water Purifier Repair</a>
									<a class="dropdown-item" href="services.html">Computer/Laptop Repair</a>
									<a class="dropdown-item" href="services.html">Lift Repair</a>
									<a class="dropdown-item" href="services.html">Plumbing</a>
									<a class="dropdown-item" href="services.html">Painting</a>
									<a class="dropdown-item" href="services.html">Wall Ceiling</a>
									<a class="dropdown-item" href="services.html">House Keeping</a>
									<a class="dropdown-item" href="services.html">Pest Control</a>
									<a class="dropdown-item" href="services.html">Sofa Repair</a>
									<a class="dropdown-item" href="services.html">Carpentry</a>
									<a class="dropdown-item" href="services.html">Catering</a>

							</div>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								Business Solutions
							</a>
							<div class="dropdown-menu">
								<a class="dropdown-item" href="business-solutions.html">Capability</a>
								<a class="dropdown-item" href="business-solutions.html">Turnkey Business Solutions</a>
								<a class="dropdown-item" href="business-solutions.html">AMC Solutions</a>
								<a class="dropdown-item" href="business-solutions.html">Market Segments</a>
							</div>
						</li>
						
						<li class="nav-item">
							<a class="nav-link text-white" href="blog.html">Blog</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="contact.html">Contact Us</a>
						</li>
					</ul>
                    
				</div>
			</nav>
            
           
		
		</div>
        
		<!-- //navigation -->
	</div>
	<!-- breadcrumb -->
	<nav aria-label="breadcrumb">
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="index.html">Home</a>
			</li>
			<li class="breadcrumb-item active" aria-current="page">Our Services</li>
		</ol>
	</nav>
    
			<div class="counter_form">
				<div class="row fill_height">
					<div class="col fill_height">
						<form class="counter_form_content d-flex flex-column align-items-center justify-content-center" role="form" method="post" id="reused_form" action="handler2.php">
							<div class="counter_form_title">Register Now</div>
							<!-- <input type="text" class="counter_input" id="name" name="name" placeholder="Your Name:" required="required" pattern="[A-Za-z ‘-]{1,15}">
							<input type="email" class="counter_input" placeholder="Email:" id="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required="true"> -->
							<input type="tel" class="counter_input" placeholder="Phone:" id="phone" name="phone" pattern="[6789][0-9]{9}" required="true">
						<!-- <select id="counter_select course" class="counter_input counter_options" name="course" required="true">
                                    <option selected disabled value="">Select Time</option>
                                    <option value="Digital Marketingl">9:00AM-10:00AM</option>
                                    <option value="Facebook Marketing">11:00AM-12:30PM</option>
                                    <option value="Search Engine Optimization">1:30PM - 3:30PM</option>
                                    <option value="Search Engine Marketing">4:30PM-6:30PM</option>
                                  </select> -->
							<!-- <textarea class="counter_input counter_text_input" placeholder="Services" required="required"  maxlength="1000"></textarea> -->
							<button type="submit" class="counter_form_button" name="submit" id="btnContactUs">Register Now</button>
						</form>
						<div id="success_message" style="width:100%; height:100%; display:none; "> <h3>Sent your message successfully!</h3> </div>
                    <div id="error_message" style="width:100%; height:100%; display:none; "> <h3>Error</h3> Sorry there was an error sending your form. </div>
					</div> 
				</div>
			</div>
	<!-- breadcrumb -->
	<!-- //banner -->

	<!-- Title-->
	<div class="course-w3ls py-5">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title text-capitalize font-weight-light text-dark text-center mb-sm-5 mb-4">Our -
				<span class="font-weight-bold">Services</span>
			</h3>
			

			
		</div>
	</div>
	<!-- //Title-->

     <section style="margin-top: -70px;">
       <div class="container-fluid">
          <div class="row">
              <div class="col-lg-3 col-md-4 col-sm-4 col-xs-5">
                  <div class="tab">
                    <button class="tablinks" onclick="openCity(event, 'tvrepair')" id="defaultOpen">TV Repair</button>
                    <button class="tablinks" onclick="openCity(event, 'refrigetarrepair')">Refrigerator Repair</button>
                    <button class="tablinks" onclick="openCity(event, 'washingmachinrepair')">Washing Machine Repair</button>
                     <button class="tablinks" onclick="openCity(event, 'micrawaverepair')" id="defaultOpen">Microwave Repair</button>
                    <button class="tablinks" onclick="openCity(event, 'acrepair')">A/C Repair</button>
                    <button class="tablinks" onclick="openCity(event, 'geyserrepair')">Geyser Repair</button>
                    <button class="tablinks" onclick="openCity(event, 'waterpurifierrepair')">Water Purifier Repair</button>
                    <button class="tablinks" onclick="openCity(event, 'computwrlaptops')">Computer / Laptop</button>
                    <button class="tablinks" onclick="openCity(event, 'liftrepair')">LIFT Repair</button>
                    <button class="tablinks" onclick="openCity(event, 'plumbingworks')">Plumbing Works</button>
                    <button class="tablinks" onclick="openCity(event, 'painting')">Painting</button>
                    <button class="tablinks" onclick="openCity(event, 'wallceiling')">Wall Ceiling</button>
                    <button class="tablinks" onclick="openCity(event, 'housekeeping')">House Keeping</button>
                    <button class="tablinks" onclick="openCity(event, 'pestcontrol')">Pest Control</button>
                    <button class="tablinks" onclick="openCity(event, 'sofarepair')">Sofa Repair</button>
                    <button class="tablinks" onclick="openCity(event, 'carpentryworks')">Carpentry Works</button>
                    <button class="tablinks" onclick="openCity(event, 'catering')">Catering</button>
                  </div>

              </div>

              <style type="text/css">
              	.tabcontent
              	{
              		height: auto;
              	}
              </style>

	 		 <div class="col-lg-9 col-md-8 col-sm-8 col-xs-7">

	 			<div class="container">
	 				<div id="tvrepair" class="tabcontent">
	 				<div class="row">

	 					<div class="col-md-6">

		                   	  <h2>TV Repair</h2>
		                   
		                      <p>We offer complete end to end TV repairs for all kinds of TV’s including Samsung, Sony, LG and other Television Brands. We have a team of highly trained Electronic Engineers and Technicians with deep experience in providing LED TV repairs of all types, shapes and sizes.</p>
		                      <p>We have been in this business for nearly 20 years offering high quality TV repair services for domestic and commercial establishment in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
		                     
		                     
                 
              			</div>

		             	<div class="col-md-6">
			              	<br>
			              	<br>
			              	<img src="images/services/tv.jpg"style="height: 300px;width: 100%">
		              	
		              	</div>
		              	 <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of Televisions, and sizes and recommend right fit advice and deliver quality service within time frame. </p>
		                      <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
		                      <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carry out completely and comprehensively to make sure they have a clean record. .</p>
               		</div>
                 </div>
               </div>

                <div class="container"> 
	                <div id="refrigetarrepair" class="tabcontent">
	                	<div class="row">
	                		<div class="col-md-6">
			                  		<h2>Refrigerator Repair</h2>
			                      <p>Our experienced team of refrigerator service engineers are adept at identifying and repairing small, medium to large refrigerators of all types of brands.  We make sure all the tools are handy and go about with their work repairing, replacing parts of refrigerators within time and budget.</p>
			                      <p>We have been in this business for nearly 20 years offering high quality Refrigerator repair services for domestic and commercial establishment in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
			                     
			                     
	              			</div>
				              <div class="col-md-6">
				              	<br>
				              	<br>
				              	<img src="images/services/refrigerator.jpg"style="height: 300px;width: 100%">
				              	
				              </div>
				               <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of Refrigerators, and sizes and recommend right fit advice and deliver quality service within time frame.  </p>
			                      <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
			                      <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carry out completely and comprehensively to make sure they have a clean record. .</p>

	             	</div>
	              </div>
            </div>

            <div class="container">
                <div id="washingmachinrepair" class="tabcontent">
                	<div class="row">
	                	<div class="col-md-6">
		                  	  <h2>Washing Machine Repair</h2>
		                      <p>We have been offering high quality washing machine repair for close to two decades now across cities like Hyderabad, Vijayawada, Vizag and Bengaluru. The hall mark of our washing machine repair services is we respond quickly to the calls, meet deadlines and make is cost effective</p>
		                      <p>We have been in this business for nearly 20 years offering high quality washing machines repair services for domestic, hospitals, hotels in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
		                     
		                     
	                	</div>
			            <div class="col-md-6">
			              	<br>
			              	<br>
			              	<img src="images/services/washing-machine.jpg"style="height: 300px;width: 100%">
			              	
			            </div>
			             <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of Washing Machines, and sizes and recommend right fit advice and deliver quality service within time frame.  </p>
		                      <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
		                      <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carry out completely and comprehensively to make sure they have a clean record. .</p>

              		</div>
              	</div>
            </div>

            <div class="container">
                <div id="micrawaverepair" class="tabcontent">
                	<div class="row">
		                 <div class="col-md-6">
		                  	  <h2>Microwave Repair</h2>
		                      <p>We are specialist In Microwave repairs. Our services engineers, over the past many years have repairs thousands of microwaves of all brands in many places. We offer door step servicing so that you don’t have to run around finding qualified service engineers.</p>
		                      <p>We have been in this business for nearly 20 years offering high quality washing machines repair services for domestic, hospitals, hotels in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
		                     
		                    

		                   </div>
			              <div class="col-md-6">
			              	<br>
			              	<br>
			              	<img src="images/services/owen.jpg"style="height: 300px;width: 100%">
			              	
			              </div>
			               <P>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of Washing Machines, and sizes and recommend right fit advice and deliver quality service within time frame.  </P>
		                      <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
		                      <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record. .</p>

              		</div>
              	</div>
            </div>

            <div class="container">
                <div id="acrepair" class="tabcontent">
                	<div class="row">
	                	<div class="col-md-6">
		                  	  <h2>A/C Repair</h2>
		                      <p>One of our core specialty is A/C repairing. We have helped numerous households, companies, hotels, and hospitals in offering A/C repair services. We are adept and experienced in installing, uninstalling, repairing A/C of all types, sizes and brands.</p>
		                      <p>We have been in this business for nearly 20 years offering high quality A/C repair services for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
		                      
		                     

	                 	 </div>
			              <div class="col-md-6">
			              	<br>
			              	<br>
			              	<img src="images/services/ac.jpg"style="height: 300px;width: 100%">
			              	
			              </div>
			              <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of A/C repair, and sizes and recommend right fit advice and deliver quality service within time frame.  </p>
		                      <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
		                      <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record. .</p>

              		</div>
               </div>
            </div>
            <div class="container">
                <div id="geyserrepair" class="tabcontent">
                	<div class="row">
                  		<div class="col-md-6">
                    		<h2>Geyser Repair</h2>
	                        <p>Our geyser repair services are well known among the households, apartments, cross many cities. Over the years, we have built a core team of geyser repair service engineers and technicians who are counted amongst the best in geyser repair.</p>
	                        <p>We have been in this business for nearly 20 years offering high quality geyser repair services for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
	                     
	                        
                    	</div>
			              <div class="col-md-6">
			              	<br>
			              	<br>
			              	<img src="images/services/Geyser.jpg"style="height: 300px;width: 100%">
			              	
			              </div>
			                 <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of geyser repair, and sizes and recommend right fit advice and deliver quality service within time frame.  </p>
	                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
	                        <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record.</p>

              		</div>
              	</div>
              </div>
              <div class="container">
                  <div id="waterpurifierrepair" class="tabcontent">
                   		<div class="row">
                   			<div class="col-md-6">
                    			<h2>Water Purifier Repair</h2>
		                        <p>Water purifier repairs are an important element in the services we offer.  Our time tested approaches in repairing, servicing or installations of water purifiers have won many accolades from our customers. We make sure we are on time, and fix the issues of water purifier within time and budget.</p>
		                        <p>We have been in this business for nearly 20 years offering high quality water purifier repair services for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
		                      
                 			</div>
			              <div class="col-md-6">
			              	<br>
			              	<br>
			              	<img src="images/services/water.jpg"style="height: 300px;width: 100%">
			              	
			              </div>
			              <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of water purifier repair, and sizes and recommend right fit advice and deliver quality service within time frame.  </p>
		                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
		                        <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record.</p>

              			</div>
              	 </div>
              </div>
              <div class="container">
                  <div id="computwrlaptops" class="tabcontent">
                   	<div class="row">
	                   	<div class="col-md-6">
	                    <h2>Computer / Laptop</h2>
	                        <p>All kinds of computers, laptops servicing is done at Dial Hari. We are experts in servicing computers and laptops at the door step, including but not limited installation of software, repairs of all kinds of branded computer & laptops and unbranded systems.</p>
	                        <p>We have been in this business for nearly 20 years offering high quality computer/laptop repair services and software installations for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
	                       
	                        
	                    </div>
		                <div class="col-md-6">
			              	<br>
			              	<br>
			              	<img src="images/services/laptop-repair.jpg"style="height: 300px;width: 100%">
		                </div>

		                 <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of computer/laptop repair, and sizes and software installations and recommend right fit advice and deliver quality service within time frame.  </p>
	                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
	                        <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record.</p>

              		</div>
              	</div>
              </div>
              <div class="container">
                 <div id="liftrepair" class="tabcontent">
                   <div class="row">
                   		<div class="col-md-6">
                    		<h2>LIFT Repair</h2>
		                        <p>We have been servicing and repairing lifts in apartments, hotels, hospitals and at corporate companies for a long time. We take annual maintenance contract and service the lifts and make sure they work without a hitch.</p>
		                        <p>We have been in this business for nearly 20 years offering high quality lift repair services and for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
		                        
		                        
                    	</div>
		                <div class="col-md-6">
			              	<br>
			              	<br>
			              	<img src="images/services/elevator.jpg"style="height: 300px;width: 100%">
		                </div>

		                <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of lift repair, and sizes and recommend right fit advice and deliver quality service within time frame.  </p>
		                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
		                        <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record.</p>

              		 </div>
              	  </div>
              </div>
              <div class="container">
                  <div id="plumbingworks" class="tabcontent">
                   	<div class="row">
                   		<div class="col-md-6">
                    		<h2>Plumbing Works</h2>
	                        <p>Plumbing works is an area where we have providing quality works for domestic, apartments and corporate companies. Over the years our plumbing workers have won accolades for their quality, and hard work by one and all. We make sure we reach on time and deliver the plumbing works without a glitch.</p>
	                        <p>We have been in this business for nearly 20 years offering high quality plumbing work services and for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
	                        
	                        
                   		</div>
                  		<div class="col-md-6">
			              	<br>
			              	<br>
			              	<img src="images/services/plumbing.jpg"style="height: 300px;width: 100%">
              	
              			</div>

              			<p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of plumbing works, and recommend right fit advice and deliver quality service within time frame.  </p>
	                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
	                        <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record.</p>

              		 </div>
              	</div>
              </div>
              <div class="container">
                  <div id="painting" class="tabcontent">
                       <div class="row">
                    		<div class="col-md-6">
                    			<h2>Painting</h2>
		                        <p>Painting is a core element of the services we offer. From offering painting works to residential apartment, commercial complexes or office buildings, we offer complete painting services to our customers. From the initial process of identifying the colours to giving finishing touches we undertake painting works delivering quality and aesthetics at the same time</p>
		                        <p>We have been in this business for nearly 20 years offering high quality painting work services and for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
		                     
		                        
                    		</div>
                   			<div class="col-md-6">
				              	<br>
				              	<br>
				              	<img src="images/services/painting.jpg"style="height: 300px;width: 100%">
              	
              				</div>
              				   <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of painting works, and recommend right fit advice and deliver quality service within time frame.  </p>
		                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
		                        <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record.</p>

              			</div>
              		</div>
              </div>
              <div class="container">
                    <div id="wallceiling" class="tabcontent">
                    	<div class="row">
                    		<div class="col-md-6">
                    			<h2>Wall Ceiling</h2>
		                        <p>Over the years we have partnered and worked with numerous construction companies in offering quality wall ceiling services for residential apartments, commercial complexes and shopping malls. Dial Hari is an accomplished wall ceiling Services Company with experienced workforce.</p>
		                        <p>We have been in this business for nearly 20 years offering high quality wall ceiling work services and for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
		                        
		                        
                    		</div>
                  	 		<div class="col-md-6">
				              	<br>
				              	<br>
				              	<img src="images/services/ceiling.jpg"style="height: 300px;width: 100%">
              	
              				</div>
              				<p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of wall ceiling works, and recommend right fit advice and deliver quality service within time frame.  </p>
		                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
		                        <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record.</p>

              			</div>
              		</div>
              </div>
              <div class="container">
                    <div id="housekeeping" class="tabcontent">
                    	<div class="row">
                    		<div class="col-md-6">
                    			<h2>House Keeping</h2>
		                        <p>We at Dial Hari offer end-to-end housekeeping services including but not limited to complete, comprehensive deep cleaning across all parts, whether it is a flat in an apartment, independent house or villa or an office building. We deploy a team of housekeeping workers with experience in cleaning the entire space.</p>
		                        <p>We have been in this business for nearly 20 years offering high quality housekeeping work services and for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
		                  
		                       
                    		</div>
                   			<div class="col-md-6">
				              	<br>
				              	<br>
				              	<img src="images/services/house-keeping.jpg"style="height: 300px;width: 100%">
	              	
              				</div>
              				      <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of housekeeping works, and recommend right fit advice and deliver quality service within time frame.  </p>
		                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
		                        <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record.</p>

              			</div>
              		</div>
              </div>
              <div class="container">
                    <div id="pestcontrol" class="tabcontent">
                    	<div class="row">
                    		<div class="col-md-6">
                    			<h2>Pest Control</h2>
		                        <p>It is extremely important to keep our premises clean and devoid of pests and make the living hygienic. We offer pest control services to a wide variety of customers, both for domestic and commercial establishment. Our pest control certified experts are trained in pest control management and only use the materials that are permitted for pest control management. </p>
		                        <p>We have been in this business for nearly 20 years offering high quality pest control work services and for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
		                        
		                        
                    		</div>
                   			<div class="col-md-6">
				              	<br>
				              	<br>
				              	<img src="images/services/pest-control.jpg"style="height: 300px;width: 100%">
              	
              				</div>
              				<p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of pest control works, and recommend right fit advice and deliver quality service within time frame.  </p>
		                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
		                        <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record.</p>

              			</div>
              		</div>
              </div>
              <div class="container">
                    <div id="sofarepair" class="tabcontent">
                    	<div class="row">
                    		<div class="col-md-6">
                    			 <h2>Sofa Repair</h2>
			                        <p>The idea to make the sofas at home or offices look good and elegant so that the whole ambiance looks pleasant. We at Dial Hari only repair sofas efficiently but improve the look and feel. We have trained sofa makers and repair technicians to man all sofa works and make your place not only beautiful and elegant but bring peace to your place.</p>
			                        <p>We have been in this business for nearly 20 years offering high quality sofa repair work services and for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
			                        
			                        
                    		</div>
		                   <div class="col-md-6">
				              	<br>
				              	<br>
				              	<img src="images/services/sofa-repair.jpg"style="height: 300px;width: 100%">
		                   </div>
		                   <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of sofa repair works, and recommend right fit advice and deliver quality service within time frame.  </p>
			                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
			                        <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record.</p>

              			</div>
              		</div>
              </div>
              <div class="container">
                    <div id="carpentryworks" class="tabcontent">
                    	<div class="row">
                    	     <div class="col-md-6">
                    				<h2>Carpentry Works</h2>
			                        <p>We make elegant carpentry works and also help with repair of all carpentry work for home and offices. Be it beds, sofas, dining tables, other furniture, we excel in all types of carpentry works. Our carpentry works are renowned in major cities as we providing excellent work within budget and time frame.</p>
			                        <p>We have been in this business for nearly 20 years offering high quality carpentry work services and for domestic, hospitals, hotels and other commercial establishments in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
			                       			                        
                     			</div>
		                      <div class="col-md-6">
				              	<br>
				              	<br>
				              	<img src="images/services/carpentry.jpg"style="height: 300px;width: 100%">
				              </div>
				               <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of carpentry works, and recommend right fit advice and deliver quality service within time frame.  </p>
			                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
			                        <p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record.</p>										

              			</div>
              		</div>
              </div>
              <div class="container">
                    <div id="catering" class="tabcontent">
                    	<div class="row">
                    		 <div class="col-md-6">
                    			<h2>Catering Services</h2>
		                        <p>Our catering services are renowned all around major cities such as Hyderabad, Vijayawada, Vizag and Bengaluru. We specialize in Hyderabadi, Andhra, & Rayalaseema Cuisine both in vegetarian and non-vegetarian categories. Our chefs come with enormous experience catering to small and large gatherings be it weddings, corporate events, parties or any other functions.</p>
		                        <p>We have been in this business for nearly 20 years offering high quality catering services for domestic parties, get together, functions, wedding, birthdays in Hyderabad, Vijayawada, Vizag and Bengaluru and very soon we will expanding our operations in other states across India.</p>
		                       
                        
                            </div>
		                    <div class="col-md-6">
				              	<br>
				              	<br>
				              	<img src="images/services/catering.jpg"style="height: 300px;width: 100%">
				              	
				            </div>
				             <p>Our technicians and service engineers are highly trained, certified and adequately equipped with all the necessary tools and equipment to carry out in depth analysis of all brands of catering services and for domestic parties, get together, functions, wedding, birthdays, and recommend right fit cuisine and deliver quality service within time frame.  </p>
		                        <p>We have implemented a series of globally accepted best practices, standards and operating procedures in each and every door step service we offer. The entire process from speaking to you on phone, understanding the requirements, type of service needed, visiting your place, analyzing and repairing services are documented to make the entire process transparent.</p>
                        		<p>The technicians and service engineers we hire pass through rigorous tests both for their technical skills and etiquette. Their background verification is carried-out completely and comprehensively to make sure they have a clean record. .</p>

              			</div>
              		</div>
              </div>

              </div>
          </div>
       </div>

     </section>
    
      <br>
     <div class="container call-us">
     	<h4 align="center">Please call us on +91 99999 99999 or just fill up the form and we will call you back immediately.</h4>
     	<a href="contact.html" class="button-agiles text-capitalize btn text-white mt-sm-5 mt-4">Contact Us</a>
     </div>
     <br>
   

     <style type="text/css">
     	.call-us
     	{
     		
     		padding: 20px;
     		text-align: center;
     		box-shadow: 12px 15px 20px 5px rgba(46,61,73,0.15); 
     	}
     </style>

<br>
	<!-- footer -->
	<footer>
		<div class="container py-4">
			<div class="row py-xl-5 py-sm-3">
				<div class="col-lg-3 col-md-5 col-sm-5 col-xs-12 map">
					<h3 class="contact-title text-capitalize text-white font-weight-light mb-sm-4 mb-3">Useful Links<br>
					<div class="underline" align="center"> </div></h3>

					<ul class="footer_ul">
						<li><a href="faq.html"><i class="fas fa-angle-right"></i>&emsp;FAQ’s</a></li>
						<li><a href="terms.html"><i class="fas fa-angle-right"></i>&emsp;Terms</a></li>
						<li><a href="privacypolicy.html"><i class="fas fa-angle-right"></i>&emsp;Privacy</a></li>
						<li><a href="disclaimer.html"><i class="fas fa-angle-right"></i>&emsp;Disclaimer</a></li>
						<li><a href="sitemap"><i class="fas fa-angle-right"></i>&emsp;Sitemap</a></li>
					</ul>
				</div>
				<div class="col-lg-5 col-md-7 col-sm-7 col-xs-12">
					<h3 class="contact-title text-capitalize text-white font-weight-light mb-sm-4 mb-3">Services<br>
					<div class="underline" align="center"> </div></h3>
					<ul class="footer_ul footer-ul2">
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;TV Repairs</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Refrigerator Repair</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Washing Machine Repair</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Micro Owen Repair</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;AC Repair</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Geyser Repair</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Water Purifier Repair</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Computer/Laptop Repair</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Lift Repair</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Plumbing</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Painting</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Wall Ceiling</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;House Keeping</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Pest Control</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Sofa Repair</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Carpentry</a></li>
						<li><a href="services.html"><i class="fas fa-angle-right"></i>&emsp;Catering</a></li>
					</ul>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 contact-agileits-w3layouts mt-lg-0 mt-4">
					<h3 class="contact-title text-capitalize text-white font-weight-light mb-sm-4 mb-3">get in
						<span class="font-weight-bold">touch</span><br>
					<div class="underline" align="center"> </div>
					</h3>
					<p class="conta-para-style border-left pl-4">If you have any questions about the services we provide simply use the form below. We try and respond to all queries
						and comments within 24 hours.</p>
					<br>
					<p class="para-agileits-w3layouts text-white">
						<i class="fas fa-map-marker pr-3"></i>Hyderabad,Telangana, India</p>
					<p class="para-agileits-w3layouts text-white my-sm-3 my-2">
						<i class="fas fa-phone pr-3"></i>+91 99999 99999</p>
					<p class="para-agileits-w3layouts">
						<i class="far fa-envelope-open pr-2"></i>
						<a href="mailto:mail@example.com" class=" text-white">info@dailhari.com</a>
					</p>
				</div>
			</div>
		</div>
		<div class="copyright-agiles py-3">
			<div class="container">
				<div class="row">
					<p class="col-lg-8 copy-right-grids text-white text-lg-left text-center mt-lg-1">© 2018 DailHari. All Rights Reserved | Design by
						<a href="https://charanwebtechnologies.com/" target="_blank">Charan Web Technologies</a>
					</p>
					<!-- social icons -->
					<div class="social-icons text-lg-right text-center col-lg-4 mt-lg-0 mt-3">
						<ul class="list-unstyled">
							<li>
								<a href="#" class="fab fa-facebook-f icon-border facebook rounded-circle"> </a>
							</li>
							<li class="mx-2">
								<a href="#" class="fab fa-twitter icon-border twitter rounded-circle"> </a>
							</li>
							<li>
								<a href="#" class="fab fa-google-plus-g icon-border googleplus rounded-circle"> </a>
							</li>
							<li class="ml-2">
								<a href="#" class="fas fa-rss icon-border rss rounded-circle"> </a>
							</li>
						</ul>
					</div>
					<!-- //social icons -->
				</div>
			</div>
		</div>
	</footer>
	<!-- //footer -->


	<!-- Js files -->
	<!-- JavaScript -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<!-- Default-JavaScript-File -->
	<script src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->

	<!-- testimonial-plugin -->
	<script src="js/mislider.js"></script>
	<script>
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

	<script>
		jQuery(function ($) {
			var slider = $('.mis-stage').miSlider({
				//  The height of the stage in px. Options: false or positive integer. false = height is calculated using maximum slide heights. Default: false
				stageHeight: 320,
				//  Number of slides visible at one time. Options: false or positive integer. false = Fit as many as possible.  Default: 1
				slidesOnStage: false,
				//  The location of the current slide on the stage. Options: 'left', 'right', 'center'. Defualt: 'left'
				slidePosition: 'center',
				//  The slide to start on. Options: 'beg', 'mid', 'end' or slide number starting at 1 - '1','2','3', etc. Defualt: 'beg'
				slideStart: 'mid',
				//  The relative percentage scaling factor of the current slide - other slides are scaled down. Options: positive number 100 or higher. 100 = No scaling. Defualt: 100
				slideScaling: 150,
				//  The vertical offset of the slide center as a percentage of slide height. Options:  positive or negative number. Neg value = up. Pos value = down. 0 = No offset. Default: 0
				offsetV: -5,
				//  Center slide contents vertically - Boolean. Default: false
				centerV: true,
				//  Opacity of the prev and next button navigation when not transitioning. Options: Number between 0 and 1. 0 (transparent) - 1 (opaque). Default: .5
				navButtonsOpacity: 1,
			});
		});
	</script>
	<!-- //testimonial-plugin -->

	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- //smooth scrolling -->

	<!-- move-top -->
	<script src="js/move-top.js"></script>
	<!-- easing -->
	<script src="js/easing.js"></script>
	<!--  necessary snippets for few javascript files -->
	<script src="js/edulearn.js"></script>

	<!-- //Js files -->

</body>

</html>